#!/bin/bash

# Actualiza los paquetes
sudo apt update
sudo apt upgrade -y

# Instala paquetes esenciales
sudo apt install -y python3 python3-venv geany thonny chromium-browser libreoffice ssh usbmount

# Habilita SSH y VNC
sudo raspi-config nonint do_ssh 0
sudo raspi-config nonint do_vnc 0

echo "Instalación completa."
