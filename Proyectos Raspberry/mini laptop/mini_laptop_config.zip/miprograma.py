import time

while True:
    print("Hola, mundo!")
    time.sleep(1)
